package it.dennis;

import it.dennis.Model.Acquisto;
import it.dennis.Repository.AcquistoDAO;
import it.dennis.Repository.AcquistoDAOImpl;
import it.dennis.Repository.ClienteDAO;
import it.dennis.Repository.ClienteDAOImpl;
import it.dennis.Service.CalcoloCashbackService;

import java.sql.Date;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        CalcoloCashbackService calcoloCashbackService = new CalcoloCashbackService();
        calcoloCashbackService.impostaPercentualeCashback();

    }
}