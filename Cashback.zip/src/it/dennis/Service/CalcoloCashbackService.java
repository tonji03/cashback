package it.dennis.Service;

import it.dennis.Model.Acquisto;
import it.dennis.Model.Cliente;
import it.dennis.Repository.*;
import org.w3c.dom.ls.LSException;

import java.sql.Date;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;

public class CalcoloCashbackService {
    ClienteDAO clienteDAO = new ClienteDAOImpl();
    AcquistoDAO acquistoDAO = new AcquistoDAOImpl();
    CashbackddDAO cashbackddDAO = new CashbackDAOImpl();

    public void calcolaCashback(){
        List<Acquisto> acquistoList = acquistoDAO.getAllAcquisti();
        List<Cliente> clienti = clienteDAO.getAllClienti();
        while (!acquistoList.isEmpty()){



        }
    }

    public void impostaPercentualeCashback(){
        List<Cliente> clienti = new ArrayList<Cliente>();
        clienti = clienteDAO.getAllClienti();
        clienti.forEach(cliente -> {
            if(!dataMinoreAnno(cliente.getData_registrazione())){
                clienteDAO.setPercentuale(cliente.getId_cliente(),12);
            }else{
                clienteDAO.setPercentuale(cliente.getId_cliente(),10);
            }
        });
    }
    private boolean dataMinoreAnno(Date date){
        LocalDate oggi = LocalDate.now();
        LocalDate data = date.toLocalDate();
        Period period = Period.between(data, oggi);
        int anni = period.getYears();

        return anni < 1;
    }
}
