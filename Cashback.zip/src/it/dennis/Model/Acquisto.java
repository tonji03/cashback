package it.dennis.Model;

import java.sql.Date;

public class Acquisto {
    private int id_acquisto;
    private int id_cliente;
    private double prezzo;
    private Date data_acquisto;

    public Acquisto(int id_acquisto, int id_cliente, double prezzo, Date data_acquisto) {
        this.id_acquisto = id_acquisto;
        this.id_cliente = id_cliente;
        this.prezzo = prezzo;
        this.data_acquisto = data_acquisto;
    }

    public Acquisto(double prezzo, Date data_acquisto) {
        this.prezzo = prezzo;
        this.data_acquisto = data_acquisto;
    }

    @Override
    public String toString() {
        return "Acquisto{" +
                "id_acquisto=" + id_acquisto +
                ", id_cliente=" + id_cliente +
                ", prezzo=" + prezzo +
                ", data_acquisto=" + data_acquisto +
                '}';
    }
}
